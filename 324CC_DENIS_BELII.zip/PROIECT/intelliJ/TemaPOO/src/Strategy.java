public interface Strategy {
    public Item execute(WishList wishList);
}
